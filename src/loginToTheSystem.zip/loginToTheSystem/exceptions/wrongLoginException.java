package loginToTheSystem.exceptions;

public class wrongLoginException extends Exception{
    public wrongLoginException() {

    }

    public wrongLoginException(String message) {
        super(message);
    }
}
